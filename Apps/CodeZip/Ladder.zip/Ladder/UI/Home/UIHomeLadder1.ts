
import GameViewController from "../../../../AppBase/Game/GameViewController";
import UIHomeBase from "../../../../AppBase/Home/UIHomeBase";
import Debug from "../../../../Common/Debug";
import UIButton from "../../../../Common/UIKit/UIButton/UIButton";
import UIImage from "../../../../Common/UIKit/UIImage/UIImage";



export default class UIHomeLadder1 extends UIHomeBase {


    /** @prop {name:nodeImageLogo,type:Node}*/
    nodeImageLogo: Laya.Node;

    /** @prop {name:nodeTextTitle,type:Node}*/

    imageLogo: UIImage;

    btnPlay: UIButton;

    onAwake() {
        super.onAwake();
        Debug.Log("UIHomeMergge uiButton  set click");

        // this.LoadSideBar();
        // this.LoadCenterBar();

        // var button = UIFind.Find(this.node, "Button");
        // // if(button!=null)
        // {
        //     this.btnPlay = UIFind.FindUI(button, "BtnPlay",UIButton);
        //     this.btnPlay.SetClick(this, this.OnBtnClickPlay.bind(this));
        // }



        // this.imageLogo = this.nodeImageLogo.getComponent(UIImage);


        // var info = GameLevelParse.main.GetLastItemInfo();
        // var pic = GameLevelParse.main.GetImagePath(info.id);
        // Debug.Log("UIHomeMerge pic=" + pic);
        // this.imageLogo.UpdateImage(pic);

        // var name = Language.main.GetString("APP_NAME");
        // if (Device.main.isLandscape) {
        //     name = Language.main.GetString("APP_NAME_HD");
        // }
        // Debug.Log("UIHomeMerge  appname=" + name);

        // this.textTitle.text = name;
        // this.LayOut();

        // //3d场景加载
        // Laya.Scene3D.load("Resources/App/LayaScene_Laya/Conventional/Laya.lh", Laya.Handler.create(this, function (scene) {
        //     //加载完成获取到了Scene3d
        //     Laya.stage.addChild(scene);
        //     //获取摄像机
        //     var camera = scene.getChildByName("Main Camera");
        //     //清除摄像机的标记
        //     camera.clearFlag = Laya.BaseCamera.CLEARFLAG_SKY;
        //     //添加光照
        //     var directionLight = scene.addChild(new Laya.DirectionLight());
        //     directionLight.color = new Laya.Vector3(1, 1, 1);
        //     directionLight.transform.rotate(new Laya.Vector3(-3.14 / 3, 0, 0));
        // }));

        var scene: Laya.Scene3D = Laya.stage.addChild(new Laya.Scene3D()) as Laya.Scene3D;
        //加载3D预设（3D精灵）
        // Laya.Sprite3D.load("Resources/App/LayaScene_Laya/Conventional/Laya.lh", Laya.Handler.create(null, function (sp) {
        //     // this.node.addChild(sp);
        //     // let pangzi: Laya.Sprite3D = scene.addChild(sp) as Laya.Sprite3D;
        // })); 

        //加载Mesh
        Debug.Log("UIHomeMergge Laya.Mesh.load");
        Laya.Mesh.load("Resources/App/LayaScene_Laya/Conventional/Assets/Script/Apps/Ladder/TabClimb/Models x/LadderSteps-Cylinder.002.lm", Laya.Handler.create(this, function (mesh) {
            var sp = new Laya.MeshSprite3D(mesh);
            this.node.addChild(sp);
            // var layaMonkey = scene.addChild(sp);
            Debug.Log("UIHomeMergge Laya.Mesh.load Finish");

        }));

    }



    onStart() {
        super.onStart();
        this.LayOut();


    }

    OnBtnClickHome() {
        Debug.Log("OnBtnClickHome");
        this.OnBtnClickPlay();
    }

    OnBtnClickPlay() {
        Debug.Log("OnBtnClickPlay");
        this.GotoGame();


    }


    GotoGame() {
        if (this.controller != null) {
            var navi = this.controller.naviController;
            Debug.Log("GotoGame GameViewController");
            navi.Push(GameViewController.main);
        } else {
            Debug.Log("GotoGame controller = null");
        }
    }


}


