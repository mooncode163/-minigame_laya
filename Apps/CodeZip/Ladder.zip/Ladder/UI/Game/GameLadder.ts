import AppSceneUtil from "../../../../AppBase/Common/AppSceneUtil";
import GameBase from "../../../../AppBase/Game/GameBase";
import PrefabCache from "../../../../Common/Cache/PrefabCache";
import Common from "../../../../Common/Common";
import Timer from "../../../../Common/Core/Timer";
import Debug from "../../../../Common/Debug";
import ResManager from "../../../../Common/Res/ResManager";
import UIImage from "../../../../Common/UIKit/UIImage/UIImage";
import UITouchEvent from "../../../../Common/UIKit/UITouchEvent";
import UI from "../../../../Common/UIKit/ViewController/UI";
import UIFind from "../../../../Common/UIKit/ViewController/UIFind";
import GameData, { GameStatus } from "../../Data/GameData";
import GameLevelParse from "../../Data/GameLevelParse";
 




export default class GameLadder extends GameBase {

    nodeDeadline: Laya.Node | null = null;

    imageProp: UIImage | null = null;
 

    static _main: GameLadder;
    //静态方法
    static get main() {
        return this._main;
    }
    onAwake() {
        super.onAwake();
        GameLadder._main = this;
        GameData.main.game = this;

    
    }
    onStart() {
        super.onStart();
        this.LayOut();
    }
    LayOut() {
        super.LayOut();
    }
    UpdateLevel(level: number) {
        super.UpdateLevel(level);
    }




    LoadPrefab() {
         

        

    }
 
}


