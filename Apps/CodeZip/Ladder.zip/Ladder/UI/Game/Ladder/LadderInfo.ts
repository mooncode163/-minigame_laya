 
export enum LadderType {
    Left = "Left",
    Right = "Right",
    Both = "Both",
}


export default class LadderInfo {

    public keyPrefab: string;
    public type: LadderType;

}


