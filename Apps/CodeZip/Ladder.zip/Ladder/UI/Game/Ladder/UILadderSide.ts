import UIView from "../../../../../Common/UIKit/ViewController/UIView";
 
export default class UILadderSide extends UIView { 
    LayOut() {
        super.LayOut();
    }

    onAwake() {
        super.onAwake(); 
    }
    onStart() {
        super.onStart();
        this.LayOut();

         
    } 
}


