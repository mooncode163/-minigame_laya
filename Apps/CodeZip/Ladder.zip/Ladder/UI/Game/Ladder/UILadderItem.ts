import UIView from "../../../../../Common/UIKit/ViewController/UIView";

// shapeCast

export default class UILadderItem extends UIView {


    LayOut() {
        super.LayOut();
    }

    onAwake() {
        super.onAwake();
    }
    onStart() {
        super.onStart();
        this.LayOut();


    }

}


