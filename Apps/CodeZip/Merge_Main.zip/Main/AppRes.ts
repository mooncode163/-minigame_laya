 
export default class AppRes  {

    public static KEY_GAME_LOCK: string = "KEY_GAME_LOCK";  
}


