import UIView3D from "../../../../Common/UIKit/ViewController/UIView3D";

export default class UIMergeItemInternal extends UIView3D {

 
    isNew = false;
    
    onAwake() {
        super.onAwake();
        

    }
    onStart() {
        super.onStart();
    } 

}


