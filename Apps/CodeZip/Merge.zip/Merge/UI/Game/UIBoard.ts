import UIView from "../../../../Common/UIKit/ViewController/UIView";

 
export default class UIBoard extends UIView {
    
    onLoad () {
        super.onAwake();
    }
    start () {
        super.onStart();
    }
     

}


