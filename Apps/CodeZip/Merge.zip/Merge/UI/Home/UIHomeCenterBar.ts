import UIView from "../../../../Common/UIKit/ViewController/UIView";


export default class UIHomeCenterBar extends UIView {


   
}


