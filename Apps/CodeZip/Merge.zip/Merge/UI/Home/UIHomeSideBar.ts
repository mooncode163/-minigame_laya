import SettingViewController from "../../../../AppBase/Setting/SettingViewController";
import Share from "../../../../Common/Share/Share";
import UIView from "../../../../Common/UIKit/ViewController/UIView";

 

 
export default class UIHomeSideBar extends UIView {
    onAwake() {
        super.onAwake(); 
        // this.LayOut();
    }
    onStart() { 
        super.onStart();
        this.LayOut();
    }
    LayOut () { 
        super.LayOut();
  
    }
    OnBtnClickShare() {
       
    }
    OnBtnClickSetting() {
       
    }
}


