import AdInsertPlatformWrapper from "../../../AdKit/Insert/AdInsertPlatformWrapper";

 
export default class AdInsertMooSnow extends AdInsertPlatformWrapper {

    interstitialAd = null;
    InitAd(source) { 
       

    }
    SetObjectInfo(objName) {

    }

    ShowAd() {
       

    }

}



