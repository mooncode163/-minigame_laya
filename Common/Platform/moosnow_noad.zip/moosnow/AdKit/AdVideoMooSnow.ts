import AdVideoPlatformWrapper from "../../../AdKit/Video/AdVideoPlatformWrapper";

 
export default class AdVideoMooSnow extends AdVideoPlatformWrapper {
    videoAd = null;

    SetObjectInfo(objName, objMethod) {

    }
    SetType(type) {

    }
    InitAd(source) {


    }
    PreLoad(source) {

    }

    ShowAd() {
        

    }
    OnClickAd() {

    }

}



